﻿namespace Erstes_Fenster
{
    partial class bt_ClickMe
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            bt_Click1 = new Button();
            bt_Click2 = new Button();
            textBox_Ergebnis = new TextBox();
            textBox_Rechenweg = new TextBox();
            bt_Addieren = new Button();
            bt_IstGleich = new Button();
            bt_Subtrahieren = new Button();
            bt_Multiplizieren = new Button();
            bt_Dividieren = new Button();
            bt_Click3 = new Button();
            bt_Click4 = new Button();
            bt_Click5 = new Button();
            bt_Click6 = new Button();
            bt_Click7 = new Button();
            bt_Click8 = new Button();
            bt_Click9 = new Button();
            bt_Loeschen = new Button();
            bt_Backspace = new Button();
            bt_Komma = new Button();
            textBox_Zahl1 = new TextBox();
            bt_Click0 = new Button();
            label_TeilungDurchNull = new Label();
            SuspendLayout();
            // 
            // bt_Click1
            // 
            bt_Click1.BackColor = SystemColors.Window;
            bt_Click1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Click1.Location = new Point(13, 409);
            bt_Click1.Name = "bt_Click1";
            bt_Click1.Size = new Size(113, 63);
            bt_Click1.TabIndex = 0;
            bt_Click1.Text = "1";
            bt_Click1.UseVisualStyleBackColor = false;
            bt_Click1.Click += btn_Click;
            // 
            // bt_Click2
            // 
            bt_Click2.BackColor = SystemColors.Window;
            bt_Click2.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Click2.Location = new Point(128, 409);
            bt_Click2.Name = "bt_Click2";
            bt_Click2.Size = new Size(113, 63);
            bt_Click2.TabIndex = 2;
            bt_Click2.Text = "2";
            bt_Click2.UseVisualStyleBackColor = false;
            bt_Click2.Click += btn_Click;
            // 
            // textBox_Ergebnis
            // 
            textBox_Ergebnis.BackColor = Color.GhostWhite;
            textBox_Ergebnis.BorderStyle = BorderStyle.None;
            textBox_Ergebnis.Font = new Font("Segoe UI", 35F, FontStyle.Bold, GraphicsUnit.Point);
            textBox_Ergebnis.Location = new Point(22, 97);
            textBox_Ergebnis.MaxLength = 16;
            textBox_Ergebnis.Name = "textBox_Ergebnis";
            textBox_Ergebnis.Size = new Size(462, 63);
            textBox_Ergebnis.TabIndex = 3;
            textBox_Ergebnis.TextChanged += textBox_Ergebnis_TextChanged;
            // 
            // textBox_Rechenweg
            // 
            textBox_Rechenweg.BackColor = Color.GhostWhite;
            textBox_Rechenweg.BorderStyle = BorderStyle.None;
            textBox_Rechenweg.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            textBox_Rechenweg.Location = new Point(22, 64);
            textBox_Rechenweg.MaxLength = 16;
            textBox_Rechenweg.Name = "textBox_Rechenweg";
            textBox_Rechenweg.Size = new Size(462, 22);
            textBox_Rechenweg.TabIndex = 4;
            textBox_Rechenweg.TextChanged += textBox_Rechenweg_TextChanged;
            // 
            // bt_Addieren
            // 
            bt_Addieren.BackColor = SystemColors.Window;
            bt_Addieren.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Addieren.Location = new Point(358, 409);
            bt_Addieren.Name = "bt_Addieren";
            bt_Addieren.Size = new Size(113, 63);
            bt_Addieren.TabIndex = 5;
            bt_Addieren.Text = "+";
            bt_Addieren.UseVisualStyleBackColor = false;
            bt_Addieren.Click += bt_Addieren_Click;
            // 
            // bt_IstGleich
            // 
            bt_IstGleich.BackColor = SystemColors.HotTrack;
            bt_IstGleich.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_IstGleich.ForeColor = SystemColors.Window;
            bt_IstGleich.Location = new Point(358, 473);
            bt_IstGleich.Name = "bt_IstGleich";
            bt_IstGleich.Size = new Size(113, 63);
            bt_IstGleich.TabIndex = 6;
            bt_IstGleich.Text = "=";
            bt_IstGleich.UseVisualStyleBackColor = false;
            bt_IstGleich.Click += bt_IstGleich_Click;
            // 
            // bt_Subtrahieren
            // 
            bt_Subtrahieren.BackColor = SystemColors.Window;
            bt_Subtrahieren.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Subtrahieren.Location = new Point(358, 344);
            bt_Subtrahieren.Name = "bt_Subtrahieren";
            bt_Subtrahieren.Size = new Size(113, 63);
            bt_Subtrahieren.TabIndex = 7;
            bt_Subtrahieren.Text = "-";
            bt_Subtrahieren.UseVisualStyleBackColor = false;
            bt_Subtrahieren.Click += bt_Subtrahieren_Click;
            // 
            // bt_Multiplizieren
            // 
            bt_Multiplizieren.BackColor = SystemColors.Window;
            bt_Multiplizieren.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Multiplizieren.Location = new Point(358, 280);
            bt_Multiplizieren.Name = "bt_Multiplizieren";
            bt_Multiplizieren.Size = new Size(113, 63);
            bt_Multiplizieren.TabIndex = 8;
            bt_Multiplizieren.Text = "x";
            bt_Multiplizieren.UseVisualStyleBackColor = false;
            bt_Multiplizieren.Click += bt_Multiplizieren_Click;
            // 
            // bt_Dividieren
            // 
            bt_Dividieren.BackColor = SystemColors.Window;
            bt_Dividieren.FlatAppearance.BorderColor = Color.Black;
            bt_Dividieren.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Dividieren.Location = new Point(358, 216);
            bt_Dividieren.Name = "bt_Dividieren";
            bt_Dividieren.Size = new Size(113, 63);
            bt_Dividieren.TabIndex = 9;
            bt_Dividieren.Text = "/";
            bt_Dividieren.UseVisualStyleBackColor = false;
            bt_Dividieren.Click += bt_Dividieren_Click;
            // 
            // bt_Click3
            // 
            bt_Click3.BackColor = SystemColors.Window;
            bt_Click3.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Click3.Location = new Point(243, 409);
            bt_Click3.Name = "bt_Click3";
            bt_Click3.Size = new Size(113, 63);
            bt_Click3.TabIndex = 10;
            bt_Click3.Text = "3";
            bt_Click3.UseVisualStyleBackColor = false;
            bt_Click3.Click += btn_Click;
            // 
            // bt_Click4
            // 
            bt_Click4.BackColor = SystemColors.Window;
            bt_Click4.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Click4.Location = new Point(13, 344);
            bt_Click4.Name = "bt_Click4";
            bt_Click4.Size = new Size(113, 63);
            bt_Click4.TabIndex = 11;
            bt_Click4.Text = "4";
            bt_Click4.UseVisualStyleBackColor = false;
            bt_Click4.Click += btn_Click;
            // 
            // bt_Click5
            // 
            bt_Click5.BackColor = SystemColors.Window;
            bt_Click5.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Click5.Location = new Point(128, 344);
            bt_Click5.Name = "bt_Click5";
            bt_Click5.Size = new Size(113, 63);
            bt_Click5.TabIndex = 12;
            bt_Click5.Text = "5";
            bt_Click5.UseVisualStyleBackColor = false;
            bt_Click5.Click += btn_Click;
            // 
            // bt_Click6
            // 
            bt_Click6.BackColor = SystemColors.Window;
            bt_Click6.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Click6.Location = new Point(243, 344);
            bt_Click6.Name = "bt_Click6";
            bt_Click6.Size = new Size(113, 63);
            bt_Click6.TabIndex = 13;
            bt_Click6.Text = "6";
            bt_Click6.UseVisualStyleBackColor = false;
            bt_Click6.Click += btn_Click;
            // 
            // bt_Click7
            // 
            bt_Click7.BackColor = SystemColors.Window;
            bt_Click7.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Click7.Location = new Point(13, 280);
            bt_Click7.Name = "bt_Click7";
            bt_Click7.Size = new Size(113, 63);
            bt_Click7.TabIndex = 14;
            bt_Click7.Text = "7";
            bt_Click7.UseVisualStyleBackColor = false;
            bt_Click7.Click += btn_Click;
            // 
            // bt_Click8
            // 
            bt_Click8.BackColor = SystemColors.Window;
            bt_Click8.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Click8.Location = new Point(128, 280);
            bt_Click8.Name = "bt_Click8";
            bt_Click8.Size = new Size(113, 63);
            bt_Click8.TabIndex = 15;
            bt_Click8.Text = "8";
            bt_Click8.UseVisualStyleBackColor = false;
            bt_Click8.Click += btn_Click;
            // 
            // bt_Click9
            // 
            bt_Click9.BackColor = SystemColors.Window;
            bt_Click9.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Click9.Location = new Point(243, 280);
            bt_Click9.Name = "bt_Click9";
            bt_Click9.Size = new Size(113, 63);
            bt_Click9.TabIndex = 16;
            bt_Click9.Text = "9";
            bt_Click9.UseVisualStyleBackColor = false;
            bt_Click9.Click += btn_Click;
            // 
            // bt_Loeschen
            // 
            bt_Loeschen.BackColor = SystemColors.Window;
            bt_Loeschen.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Loeschen.Location = new Point(128, 216);
            bt_Loeschen.Name = "bt_Loeschen";
            bt_Loeschen.Size = new Size(113, 63);
            bt_Loeschen.TabIndex = 18;
            bt_Loeschen.Text = "C";
            bt_Loeschen.UseVisualStyleBackColor = false;
            bt_Loeschen.Click += bt_Loeschen_Click;
            // 
            // bt_Backspace
            // 
            bt_Backspace.BackColor = SystemColors.Window;
            bt_Backspace.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Backspace.Location = new Point(243, 216);
            bt_Backspace.Name = "bt_Backspace";
            bt_Backspace.Size = new Size(113, 63);
            bt_Backspace.TabIndex = 19;
            bt_Backspace.Text = "<";
            bt_Backspace.UseVisualStyleBackColor = false;
            bt_Backspace.Click += bt_Backspace_Click;
            // 
            // bt_Komma
            // 
            bt_Komma.BackColor = SystemColors.Window;
            bt_Komma.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Komma.Location = new Point(243, 473);
            bt_Komma.Name = "bt_Komma";
            bt_Komma.Size = new Size(113, 63);
            bt_Komma.TabIndex = 20;
            bt_Komma.Text = ",";
            bt_Komma.UseVisualStyleBackColor = false;
            bt_Komma.Click += bt_Komma_Click;
            // 
            // textBox_Zahl1
            // 
            textBox_Zahl1.BackColor = Color.GhostWhite;
            textBox_Zahl1.BorderStyle = BorderStyle.None;
            textBox_Zahl1.Cursor = Cursors.Help;
            textBox_Zahl1.Font = new Font("Segoe UI", 35F, FontStyle.Bold, GraphicsUnit.Point);
            textBox_Zahl1.Location = new Point(22, 97);
            textBox_Zahl1.MaxLength = 16;
            textBox_Zahl1.Name = "textBox_Zahl1";
            textBox_Zahl1.Size = new Size(462, 63);
            textBox_Zahl1.TabIndex = 21;
            textBox_Zahl1.TextChanged += textBox_Zahl1_TextChanged;
            // 
            // bt_Click0
            // 
            bt_Click0.BackColor = SystemColors.Window;
            bt_Click0.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Regular, GraphicsUnit.Point);
            bt_Click0.Location = new Point(128, 473);
            bt_Click0.Name = "bt_Click0";
            bt_Click0.Size = new Size(113, 63);
            bt_Click0.TabIndex = 17;
            bt_Click0.Text = "0";
            bt_Click0.UseVisualStyleBackColor = false;
            bt_Click0.Click += btn_Click;
            // 
            // label_TeilungDurchNull
            // 
            label_TeilungDurchNull.AutoSize = true;
            label_TeilungDurchNull.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            label_TeilungDurchNull.Location = new Point(104, 173);
            label_TeilungDurchNull.Name = "label_TeilungDurchNull";
            label_TeilungDurchNull.Size = new Size(295, 28);
            label_TeilungDurchNull.TabIndex = 22;
            label_TeilungDurchNull.Text = "Teilung durch 0 nicht möglich";
            label_TeilungDurchNull.Visible = false;
            // 
            // bt_ClickMe
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            AutoSizeMode = AutoSizeMode.GrowAndShrink;
            BackColor = Color.GhostWhite;
            ClientSize = new Size(844, 548);
            Controls.Add(label_TeilungDurchNull);
            Controls.Add(bt_Komma);
            Controls.Add(bt_Backspace);
            Controls.Add(bt_Loeschen);
            Controls.Add(bt_Click9);
            Controls.Add(bt_Click0);
            Controls.Add(bt_Click8);
            Controls.Add(bt_Click7);
            Controls.Add(bt_Click6);
            Controls.Add(bt_Click5);
            Controls.Add(bt_Click4);
            Controls.Add(bt_Click3);
            Controls.Add(bt_Dividieren);
            Controls.Add(bt_Multiplizieren);
            Controls.Add(bt_Subtrahieren);
            Controls.Add(bt_IstGleich);
            Controls.Add(bt_Addieren);
            Controls.Add(textBox_Rechenweg);
            Controls.Add(textBox_Ergebnis);
            Controls.Add(bt_Click2);
            Controls.Add(bt_Click1);
            Controls.Add(textBox_Zahl1);
            Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            MaximizeBox = false;
            Name = "bt_ClickMe";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button bt_Click1;
        private Button bt_Click2;
        private TextBox textBox_Ergebnis;
        private TextBox textBox_Rechenweg;
        private Button bt_Addieren;
        private Button bt_IstGleich;
        private Button bt_Subtrahieren;
        private Button bt_Multiplizieren;
        private Button bt_Dividieren;
        private Button bt_Click3;
        private Button bt_Click4;
        private Button bt_Click5;
        private Button bt_Click6;
        private Button bt_Click7;
        private Button bt_Click8;
        private Button bt_Click9;
        private Button bt_Loeschen;
        private Button bt_Backspace;
        private Button bt_Komma;
        private TextBox textBox_Zahl1;
        private Button bt_Click0;
        private Label label_TeilungDurchNull;
    }
}